#include <stdio.h>

int main(void)
{
    printf("I am  a child\n");

    return 100;
}
